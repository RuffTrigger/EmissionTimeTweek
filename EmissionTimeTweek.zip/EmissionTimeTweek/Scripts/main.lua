--[[----------------------------------------------------------------------------
    Mod:    EmissionTimeTweek
    Author: Ruff Trigger

    Description:
      Lets you change the emission timer length by editing one value:
        EMISSION_TIME_SECONDS

      The mod does NOT freeze or cancel emissions.
      It only overrides the "TimeUntilEmmision" value once per emission cycle,
      so emissions still happen, just at your custom interval.

      Additionally, it can play the vanilla 2-minute siren before each emission:
        /Game/Sounds/S_2minSiren_Cue.S_2minSiren_Cue

      You can enable/disable the siren and change when it starts.
----------------------------------------------------------------------------]]--

local MOD_NAME = "EmissionTimeTweek"

------------------------------------------------------------
-- Requires / helpers from shared
------------------------------------------------------------

local UEHelpers = require("UEHelpers")
local GetGameplayStatics = UEHelpers.GetGameplayStatics

------------------------------------------------------------
-- Config
------------------------------------------------------------

-- How long until the next emission from a fresh emission cycle (in seconds).
-- Examples:
--   600   = 10 minutes
--   1800  = 30 minutes
--   3600  = 60 minutes (1 hour)
--   7200  = 120 minutes (2 hours)
local EMISSION_TIME_SECONDS = 250

-- Enable/disable siren playback via GameplayStatics::PlaySound2D
local ENABLE_SIREN = true

-- When to start the siren before emission (in seconds).
-- Default: 120.0 -> matches the "2minSiren" name.
local SIREN_THRESHOLD_SECONDS = 120.0

-- How often to log status (every N updates)
local LOG_EVERY_N_UPDATES = 30

-- How big a jump (in seconds) we consider to mean "new cycle started"
local NEW_CYCLE_JUMP_THRESHOLD = 60.0

------------------------------------------------------------
-- Simple logger
------------------------------------------------------------
local function log(msg)
    print("[Lua][" .. MOD_NAME .. "] " .. tostring(msg) .. "\n")
end

------------------------------------------------------------
-- Helpers
------------------------------------------------------------

-- Unwrap RemoteUnrealParam -> Lua number
local function unwrapNumber(v)
    if v == nil then
        return nil
    end

    local tv = type(v)

    if tv == "number" then
        return v
    end

    -- UE4SS RemoteUnrealParam is usually table/userdata with .get()
    if (tv == "table" or tv == "userdata") and v.get then
        local ok, num = pcall(v.get, v)
        if ok and type(num) == "number" then
            return num
        end
    end

    return nil
end

-- Format seconds as MM:SS
local function formatTime(seconds)
    if not seconds then
        return "??:??"
    end

    if seconds <= 0.0 then
        return "EMISSION!"
    end

    local total = math.floor(seconds + 0.5)
    local mins = math.floor(total / 60)
    local secs = total % 60

    if mins > 99 then
        mins = 99
    end

    return string.format("%02d:%02d", mins, secs)
end

------------------------------------------------------------
-- Global manager cache
------------------------------------------------------------

local GLOBAL_MANAGER_CLASS = "BP_GlobalManager_C"
local gm = nil
local gmMissingLogged = false
local timePropMissingLogged = false
local setPropErrorLogged = false

local function getGlobalManager()
    if gm ~= nil then
        return gm
    end

    local inst = FindFirstOf(GLOBAL_MANAGER_CLASS)
    if inst ~= nil then
        gm = inst
        log("Found " .. GLOBAL_MANAGER_CLASS .. ": " .. gm:GetFullName().."\n")
    else
        if not gmMissingLogged then
            gmMissingLogged = true
            log(GLOBAL_MANAGER_CLASS .. " not found in world yet.".."\n")
        end
    end

    return gm
end

------------------------------------------------------------
-- Siren playback
------------------------------------------------------------

-- Cached siren cue object
local SirenCue = nil

local function ensureSirenCue()
    if SirenCue ~= nil and SirenCue:IsValid() then
        return SirenCue
    end

    -- Vanilla siren sound cue from the dumps:
    -- /Game/Sounds/S_2minSiren_Cue.S_2minSiren_Cue
    local path = "/Game/Sounds/S_2minSiren_Cue.S_2minSiren_Cue"
    SirenCue = StaticFindObject(path) or LoadObject(nil, path)

    if not SirenCue or not SirenCue:IsValid() then
        log("Failed to load siren cue: " .. path.."\n")
        SirenCue = nil
        return nil
    end

    log("Loaded siren cue: " .. SirenCue:GetFullName().."\n")
    return SirenCue
end

local function playSiren()
    if not ENABLE_SIREN then
        return
    end

    local gs = GetGameplayStatics()
    if not gs or not gs:IsValid() then
        log("GameplayStatics not valid, cannot play siren.".."\n")
        return
    end

    local world = UEHelpers.GetWorld()
    if not world or not world:IsValid() then
        log("World not valid, cannot play siren.".."\n")
        return
    end

    local cue = ensureSirenCue()
    if not cue then
        return
    end

    -- UGameplayStatics::PlaySound2D expects 8 parameters in this build:
    -- WorldContextObject, Sound, Volume, Pitch, StartTime,
    -- AttenuationSettings, ConcurrencySettings, OwningActor/Location/etc.
    -- We only care about the first 5, so we pass nil for the rest.
    local ok, err = pcall(function()
        gs:PlaySound2D(world, cue, 1.0, 1.0, 0.0, nil, nil, nil)
    end)

    if not ok then
        log("Failed to play siren (PlaySound2D): " .. tostring(err).."\n")
    else
        log("Siren played via PlaySound2D.".."\n")
    end
end

------------------------------------------------------------
-- Tick logic (hooked on BP_CharacterComponent.ReceiveTick)
------------------------------------------------------------

local firstTickLogged = false
local accumTime = 0.0
local updateCount = 0

-- Used to detect a "new emission cycle"
local lastTimeLeft = nil
local customApplied = false   -- is our custom time set for this cycle?
local sirenPlayed = false     -- has siren been played this cycle?

local function onTick(selfParam, deltaParam)
    if not firstTickLogged then
        firstTickLogged = true
        log("ReceiveTick is running (BP_CharacterComponent).".."\n")
    end

    local dt = unwrapNumber(deltaParam) or 0.0
    if dt <= 0.0 then
        return
    end

    -- Run logic roughly once per second
    accumTime = accumTime + dt
    if accumTime < 1.0 then
        return
    end
    accumTime = 0.0

    local gmInst = getGlobalManager()
    if gmInst == nil then
        return
    end

    -- Read current emission time
    local rawTime = gmInst.TimeUntilEmmision
    local timeLeft = unwrapNumber(rawTime) or tonumber(rawTime)

    if timeLeft == nil then
        if not timePropMissingLogged then
            timePropMissingLogged = true
            log("TimeUntilEmmision property not readable (type: " .. type(rawTime) .. ").".."\n")
        end
        return
    end

    --------------------------------------------------------
    -- Detect new emission cycle
    -- Case 1: timer wrapped (<= 0 -> > 0)
    -- Case 2: big positive jump (game restarted the timer)
    --------------------------------------------------------
    if lastTimeLeft ~= nil then
        local wrapped = (lastTimeLeft <= 0 and timeLeft > 0)
        local jumpedUp = (timeLeft > lastTimeLeft + NEW_CYCLE_JUMP_THRESHOLD)

        if wrapped or jumpedUp then
            customApplied = false
            sirenPlayed = false
        end
    end

    --------------------------------------------------------
    -- Apply our custom emission time only once per cycle
    --------------------------------------------------------
    if timeLeft > 0 and not customApplied then
        local okSet, errSet = pcall(function()
            gmInst.TimeUntilEmmision = EMISSION_TIME_SECONDS
        end)

        if not okSet then
            if not setPropErrorLogged then
                setPropErrorLogged = true
                log("Failed to set TimeUntilEmmision: " .. tostring(errSet).."\n")
            end
        else
            timeLeft = EMISSION_TIME_SECONDS
            customApplied = true
        end
    end

    --------------------------------------------------------
    -- Siren: play once when below threshold
    --------------------------------------------------------
    if ENABLE_SIREN and not sirenPlayed and timeLeft > 0 and timeLeft <= SIREN_THRESHOLD_SECONDS then
        playSiren()
        sirenPlayed = true
    end

    lastTimeLeft = timeLeft

    --------------------------------------------------------
    -- Logging
    --------------------------------------------------------
    updateCount = updateCount + 1
    if updateCount % LOG_EVERY_N_UPDATES == 0 then
        local nice = formatTime(timeLeft)
        local msg = "Next emission in: " .. nice ..
            " (CUSTOM=" .. tostring(EMISSION_TIME_SECONDS) ..
            "s, applied=" .. tostring(customApplied) ..
            ", sirenPlayed=" .. tostring(sirenPlayed) .. ")"
        log(msg.."\n")
    end
end

------------------------------------------------------------
-- Hook BP_CharacterComponent.ReceiveTick via ClientRestart
------------------------------------------------------------

local tickHookRegistered = false

local function registerTickHook()
    if tickHookRegistered then
        return
    end

    local fnPath =
        "/Game/SurvivalGameKitV2/Components/BP_CharacterComponent.BP_CharacterComponent_C:ReceiveTick"

    local ok, err = pcall(function()
        RegisterHook(
            fnPath,
            function(self, DeltaSeconds)
                local ok2, err2 = pcall(onTick, self, DeltaSeconds)
                if not ok2 then
                    log("Error in onTick: " .. tostring(err2).."\n")
                end
            end,
            nil -- post-callback
        )
    end)

    if not ok then
        log("Failed to hook BP_CharacterComponent.ReceiveTick: " .. tostring(err) .."\n")
    else
        tickHookRegistered = true
        log("Tick hook registered on BP_CharacterComponent.ReceiveTick.".."\n")
    end
end

-- Entry point: hook on ClientRestart
RegisterHook(
    "/Script/Engine.PlayerController:ClientRestart",
    function()
        log("ClientRestart fired, trying to register emission tick hook...".."\n")
        registerTickHook()
    end,
    nil -- post-callback
)

log("EmissionTimeTweek loaded. Waiting for PlayerController.ClientRestart...".."\n")
